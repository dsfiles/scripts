#!/bin/bash
declare -i num
echo "I'm thinking of a number between 1 and 100."
# Give num a value to prevent errors.
num=0
guess=23
while test $num -ne $guess
do
	echo "What is your guess?"
	read num
	if test $num -lt $guess 
	then
		echo "The number is higher."
	fi
	if test $num -gt $guess 
	then
		echo "The number is lower."
	fi
done
echo "You guessed it."
exit 0
