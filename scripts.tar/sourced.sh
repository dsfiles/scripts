echo $$
A="This script is sourced"
echo $A
