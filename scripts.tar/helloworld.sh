#!/bin/bash
echo "Hello World!"
cat /etc/shadow
