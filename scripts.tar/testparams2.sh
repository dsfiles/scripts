#!/bin/bash
echo "Positional Parameters"
echo '$1 = ' $1
echo '$9 = ' $9
echo '$10 = ' ${10}
echo '$11 = ' ${11}
exit 0
